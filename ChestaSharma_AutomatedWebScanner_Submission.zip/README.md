# Automated Web Scanner

**Author:** Chesta Sharma  
**Department:** Forensic Science  
**Program:** IBM SkillsBuild Cyber Security 2026 (BharatCares)

## Project description
A small Python tool that performs a low-impact review of HTTP security headers and observes basic CORS response behavior. It saves timestamped JSON and CSV records that can support further defensive review.

The tool sends ordinary HTTP `GET` and `OPTIONS` requests. It does not exploit vulnerabilities, crawl the website, brute-force, or attempt authentication bypasses. A finding is an indicator for manual review, not proof of a vulnerability, compromise, or criminal activity.

## Technologies
- Python 3.10 or later
- `requests`
- Jupyter Notebook
- JSON and CSV for report output

## Dataset
This project does **not** require a machine-learning dataset. It inspects live HTTP responses from a target that the operator is authorized to assess. For safe learning about the underlying standards, see:
- OWASP Secure Headers Project: https://owasp.org/www-project-secure-headers/
- MDN HTTP headers: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers
- MDN CORS guide: https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS

## Setup
1. Install Python 3.10+ and Jupyter.
2. Place the notebook and `requirements.txt` in the same folder.
3. Create and activate a virtual environment (recommended).
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Start Jupyter:
   ```bash
   jupyter notebook
   ```
6. Open `ChestaSharma_AutomatedWebScanner.ipynb`, run the install/import cells, and set `TARGET_URL` to a site you own or have explicit permission to assess.
7. Run the scan and report-save cells. Reports are written to `scan_reports/`.

## Output
- JSON: target, timestamps, HTTP status, selected response metadata, header findings, and CORS observations.
- CSV: tabular findings suitable for review.

## Responsible use and limitations
- Only assess systems you own or are explicitly authorized to test.
- Do not scan arbitrary third-party websites.
- This tool is intentionally non-invasive and is not a full vulnerability scanner.
- Header absence is not always a vulnerability; application context matters.
- CORS behavior varies across endpoints and request types.
- Results have not been pre-filled with fabricated findings or accuracy scores. Run the notebook to obtain actual observations for your authorized target.

## Submission files
- `ChestaSharma_AutomatedWebScanner.ipynb`
- `requirements.txt`
- `ChestaSharma_ProjectReport.docx`
- `README.md`
